package Utils;

import DAO.*;
import UI.LoginFrame;
import UI.MainFrameForAdmin;
import UI.MainFrameForStudent;
import UI.ModifySchoolInfoDialog;

import javax.swing.*;

public class CommonData {
    public static ModifySchoolInfoDialog msid = null;
    public static Admin admin = null;
    public static Student student = null;
    public static StudentDAO studentDAO = new StudentDAO();
    public static AdminDAO adminDAO = new AdminDAO();
    public static SchoolInfoDAO schoolInfoDAO = new SchoolInfoDAO();
    public static SchoolListDAO schoolListDAO = new SchoolListDAO();
    public static String userAccount =null;
    public static String userPassword=null;

    public static MainFrameForAdmin mainFrameForAdmin = new MainFrameForAdmin();
    public static MainFrameForStudent mainFrameForStudent = new MainFrameForStudent();
    public static LoginFrame loginFrame = new LoginFrame();
    /*public  static JCheckBox rememberPasswordcheckBox =new JCheckBox();
    public  static JCheckBox rememberAccountcheckBox =new JCheckBox();*/
}
