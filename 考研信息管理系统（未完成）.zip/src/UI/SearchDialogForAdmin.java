/*
 * Created by JFormDesigner on Sun Apr 24 21:58:13 CST 2022
 */

package UI;

import java.awt.*;
import javax.swing.*;
import javax.swing.GroupLayout;
import javax.swing.border.*;

/**
 * @author 1
 */
public class SearchDialogForAdmin extends JDialog {
    public SearchDialogForAdmin(Window owner) {
        super(owner);
        initComponents();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        dialogPane = new JPanel();
        contentPanel = new JPanel();
        table2 = new JTable();
        button2 = new JButton();
        comboBox1 = new JComboBox<>();
        scrollPane1 = new JScrollPane();
        textArea1 = new JTextArea();
        button3 = new JButton();
        okButton = new JButton();
        label1 = new JLabel();

        //======== this ========
        setTitle("\u7ba1\u7406\u5458\u67e5\u8be2\u7cfb\u7edf");
        var contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== dialogPane ========
        {
            dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
            dialogPane.setLayout(new BorderLayout());

            //======== contentPanel ========
            {

                //---- button2 ----
                button2.setText("\u6e05\u9664\u6570\u636e");

                //---- comboBox1 ----
                comboBox1.setModel(new DefaultComboBoxModel<>(new String[] {
                    "\u6309\u5730\u533a\u67e5\u8be2\u5b66\u6821",
                    "\u6309\u7c7b\u578b\u67e5\u8be2\u5b66\u6821",
                    "\u6309\u540d\u79f0\u67e5\u8be2\u5b66\u6821",
                    "\u6309\u540d\u79f0\u67e5\u8be2\u5b66\u6821\u4e13\u4e1a\u8bfe",
                    "\u6309\u7528\u6237\u540d\u67e5\u8be2\u7528\u6237",
                    "\u6309\u7528\u6237\u540d\u67e5\u8be2\u7ba1\u7406\u5458",
                    "\u67e5\u8be2\u6240\u6709\u7528\u6237",
                    "\u67e5\u8be2\u6240\u6709\u7ba1\u7406\u5458"
                }));

                //======== scrollPane1 ========
                {

                    //---- textArea1 ----
                    textArea1.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
                    scrollPane1.setViewportView(textArea1);
                }

                //---- button3 ----
                button3.setText("\u67e5\u8be2");

                //---- okButton ----
                okButton.setText("\u8fd4\u56de\u4e3b\u754c\u9762");

                //---- label1 ----
                label1.setText("\u8fd9\u91cc\u662f\u63d0\u793a\u4fe1\u606f");
                label1.setHorizontalAlignment(SwingConstants.CENTER);
                label1.setForeground(Color.red);

                GroupLayout contentPanelLayout = new GroupLayout(contentPanel);
                contentPanel.setLayout(contentPanelLayout);
                contentPanelLayout.setHorizontalGroup(
                    contentPanelLayout.createParallelGroup()
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                            .addContainerGap(62, Short.MAX_VALUE)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(comboBox1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                    .addGap(12, 12, 12)
                                    .addComponent(scrollPane1, GroupLayout.PREFERRED_SIZE, 387, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(button3)
                                    .addGap(6, 6, 6)
                                    .addComponent(button2))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addGap(32, 32, 32)
                                    .addComponent(table2, GroupLayout.PREFERRED_SIZE, 621, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addGap(110, 110, 110)
                                    .addComponent(label1, GroupLayout.PREFERRED_SIZE, 457, GroupLayout.PREFERRED_SIZE)
                                    .addGap(63, 63, 63)
                                    .addComponent(okButton)))
                            .addGap(37, 37, 37))
                );
                contentPanelLayout.setVerticalGroup(
                    contentPanelLayout.createParallelGroup()
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                            .addContainerGap(40, Short.MAX_VALUE)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addComponent(comboBox1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                .addComponent(button3)
                                .addComponent(button2)
                                .addComponent(scrollPane1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
                            .addGap(12, 12, 12)
                            .addComponent(table2, GroupLayout.PREFERRED_SIZE, 272, GroupLayout.PREFERRED_SIZE)
                            .addGap(12, 12, 12)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addComponent(label1)
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addGap(9, 9, 9)
                                    .addComponent(okButton)))
                            .addGap(29, 29, 29))
                );
            }
            dialogPane.add(contentPanel, BorderLayout.CENTER);
        }
        contentPane.add(dialogPane, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel dialogPane;
    private JPanel contentPanel;
    private JTable table2;
    private JButton button2;
    private JComboBox<String> comboBox1;
    private JScrollPane scrollPane1;
    private JTextArea textArea1;
    private JButton button3;
    private JButton okButton;
    private JLabel label1;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
