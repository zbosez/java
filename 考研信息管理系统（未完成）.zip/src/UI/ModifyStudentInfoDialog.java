/*
 * Created by JFormDesigner on Sun Apr 24 21:52:56 CST 2022
 */

package UI;

import javax.swing.event.*;
import DAO.Student;

import java.awt.*;
import java.awt.event.*;
import java.util.Objects;
import javax.swing.*;
import javax.swing.GroupLayout;
import javax.swing.border.*;

import static Utils.CommonData.*;

/**
 * @author 1
 */
public class ModifyStudentInfoDialog extends JDialog {
    public ModifyStudentInfoDialog(Window owner,int key) {
        super(owner);
        initComponents();
        studentpasswordField.setEchoChar('*');
        if(key==1){
            variableButton.setText("ע���û�");
            tips.setText("���������������˻��������룬���б���ԺУ�ͱ���ԺУ�����Լ����ļ��ᣡ");
        } else if (key == 2) {
            variableButton.setText("ɾ���û�");
            tips.setText("�������û�������ɾ��");

        } else if (key ==3) {
            variableButton.setText("�޸��û�");
        }
    }


    private void showPasswordRadioButtonStateChanged(ChangeEvent e) {
        if(showPasswordRadioButton.isSelected()){
            studentpasswordField.setEchoChar('\0');
        }
        else{
            studentpasswordField.setEchoChar('*');
        }
    }

    private void accountTextFieldFocusGained(FocusEvent e) {

            studentNameTextField.setText("");
            variableButton.setEnabled(true);

    }

    private void backToMainHome(ActionEvent e) {

        this.dispose();
        loginFrame.setVisible(true);


    }


    private void variable(ActionEvent e) {

        if (variableButton.getText().equals("ע���û�")){
            if(!studentNameTextField.getText().equals("")&&!new String(studentpasswordField.getPassword()).equals("")&&
            !schoolField.getText().equals("")&&!schoolLevelField.getText().equals("")&&!homeField.getText().equals("")){
                String[] info = new String[10];
                info[0]= studentNameTextField.getText();
                info[1]= new String(studentpasswordField.getPassword());
                info[2]= schoolField.getText();
                info[3]= schoolLevelField.getText();
                info[4]= homeField.getText();
                info[5]= dreamSchoolLevelField.getText().equals("")?null:dreamSchoolLevelField.getText();
                info[6]= dreamSchoolPlaceField.getText().equals("")?null:dreamSchoolPlaceField.getText();
                info[7]= dreamSchoolNameField.getText().equals("")?null:dreamSchoolNameField.getText();
                if(studentDAO.AddStudent(info) != null){
                    JOptionPane.showMessageDialog(ModifyStudentInfoDialog.this,"ע��ɹ���");
                    ModifyStudentInfoDialog.this.dispose();
                    mainFrameForStudent.dispose();
                    LoginFrame loginFrame = new LoginFrame();
                    loginFrame.setVisible(true);
                }
                else{
                    tips.setText("ע��ѧ���û�ʧ��!");
                }
            }
            else{
                tips.setText("���������������˻��������룬���б���ԺУ�ͱ���ԺУ�����Լ����ļ��ᣡ");
            }
        }
        else if(variableButton.getText().equals("ɾ���û�")){
            if(!studentNameTextField.getText().equals("")){
                if(studentDAO.DeleteStudent(studentNameTextField.getText())&&student.getStudentName().equals(studentNameTextField.getText())){
                    JOptionPane.showMessageDialog(ModifyStudentInfoDialog.this,"ɾ����ǰ�û��ɹ�!��");
                    ModifyStudentInfoDialog.this.dispose();
                    mainFrameForStudent.dispose();
                    LoginFrame loginFrame = new LoginFrame();
                    loginFrame.setVisible(true);
                }
                else {
                    tips.setText("ɾ���û�ʧ�ܣ������뵱ǰ��¼�˻����û���!");
                }
            }
            else {
                tips.setText("�������û�����");
            }
        }
        else if(variableButton.getText().equals("�޸��û�")){
            if(!studentNameTextField.getText().equals("")){
                String[] info = new String[10];
                info[0]= studentNameTextField.getText();
                info[1]= new String(studentpasswordField.getPassword());
                info[2]= schoolField.getText();
                info[3]= schoolLevelField.getText();
                info[4]= homeField.getText();
                info[5]= dreamSchoolLevelField.getText().equals("")?null:dreamSchoolLevelField.getText();
                info[6]= dreamSchoolPlaceField.getText().equals("")?null:dreamSchoolPlaceField.getText();
                info[7]= dreamSchoolNameField.getText().equals("")?null:dreamSchoolNameField.getText();
                if(studentDAO.ModifyStudent(info)!=null&&student.getStudentName().equals(studentNameTextField.getText())){
                    JOptionPane.showMessageDialog(ModifyStudentInfoDialog.this,"�޸ĵ�ǰ�û��ɹ�!��");
                    ModifyStudentInfoDialog.this.dispose();
                    mainFrameForStudent.dispose();
                    LoginFrame loginFrame = new LoginFrame();
                    loginFrame.setVisible(true);
                }
                else {
                    tips.setText("�޸��û�ʧ�ܣ������뵱ǰ��¼�˻����û���!");
                }
            }
            else {
                tips.setText("�������û�����");
            }
        }
    }

    private void find(ActionEvent e) {
        if(!studentNameTextField.getText().equals("")){
            student = studentDAO.ViewSelectedStudent(studentNameTextField.getText());
            studentNameTextField.setText(student.getStudentName());
            studentpasswordField.setText(student.getStudentPassword());
            schoolField.setText(student.getSchoolName());
            schoolLevelField.setText(student.getSchoolType());
            homeField.setText(student.getCameFrom());
            dreamSchoolLevelField.setText(student.getDreamSchoolType());
            dreamSchoolPlaceField.setText(student.getDreamSchoolLoc());
            dreamSchoolNameField.setText(student.getDreamSchoolName());
            JOptionPane.showMessageDialog(ModifyStudentInfoDialog.this,"�����Ʋ���ѧ���ɹ���");
        }
        else{
            tips.setText("������ѧ���û���!");
        }
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        dialogPane = new JPanel();
        contentPanel = new JPanel();
        label1 = new JLabel();
        label2 = new JLabel();
        label3 = new JLabel();
        label4 = new JLabel();
        label5 = new JLabel();
        label6 = new JLabel();
        label7 = new JLabel();
        label8 = new JLabel();
        label9 = new JLabel();
        studentNameTextField = new JTextField();
        schoolField = new JTextField();
        schoolLevelField = new JTextField();
        homeField = new JTextField();
        dreamSchoolLevelField = new JTextField();
        dreamSchoolPlaceField = new JTextField();
        dreamSchoolNameField = new JTextField();
        studentpasswordField = new JPasswordField();
        showPasswordRadioButton = new JRadioButton();
        backToMainHome = new JButton();
        variableButton = new JButton();
        tips = new JLabel();
        dreamschoolNamelabel = new JLabel();
        passwordlabel = new JLabel();
        schoollabel = new JLabel();
        schoolLevellabel = new JLabel();
        homelabel = new JLabel();
        dreamschoolTypelabel = new JLabel();
        acoountlabel = new JLabel();
        dreamschoolLoclabel = new JLabel();
        findButton = new JButton();

        //======== this ========
        setTitle("\u7528\u6237\u6ce8\u518c\u754c\u9762");
        var contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== dialogPane ========
        {
            dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
            dialogPane.setLayout(new BorderLayout());

            //======== contentPanel ========
            {

                //---- label1 ----
                label1.setText("\u7528\u6237\u540d");
                label1.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label2 ----
                label2.setText("\u5bc6\u7801");
                label2.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label3 ----
                label3.setText("\u672c\u79d1\u9662\u6821");
                label3.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label4 ----
                label4.setText("\u672c\u79d1\u9662\u6821\u7ea7\u522b");
                label4.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label5 ----
                label5.setText("\u7c4d\u8d2f");
                label5.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label6 ----
                label6.setText("\u5fd7\u613f\u5b66\u6821\u7c7b\u578b");
                label6.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label7 ----
                label7.setText("\u5fd7\u613f\u5b66\u6821\u5730\u5740");
                label7.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label8 ----
                label8.setText("\u5fd7\u613f\u5b66\u6821\u540d\u79f0");
                label8.setHorizontalAlignment(SwingConstants.CENTER);

                //---- label9 ----
                label9.setText("\u6b22\u8fce\u8fdb\u5165\u6ce8\u518c\u754c\u9762");
                label9.setHorizontalAlignment(SwingConstants.CENTER);
                label9.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 22));

                //---- studentNameTextField ----
                studentNameTextField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));
                studentNameTextField.addFocusListener(new FocusAdapter() {
                    @Override
                    public void focusGained(FocusEvent e) {
                        accountTextFieldFocusGained(e);
                    }
                });

                //---- schoolField ----
                schoolField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));

                //---- schoolLevelField ----
                schoolLevelField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));

                //---- homeField ----
                homeField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));

                //---- dreamSchoolLevelField ----
                dreamSchoolLevelField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));

                //---- dreamSchoolPlaceField ----
                dreamSchoolPlaceField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));

                //---- dreamSchoolNameField ----
                dreamSchoolNameField.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));

                //---- studentpasswordField ----
                studentpasswordField.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));

                //---- showPasswordRadioButton ----
                showPasswordRadioButton.setText("\u663e\u793a\u5bc6\u7801");
                showPasswordRadioButton.addChangeListener(e -> showPasswordRadioButtonStateChanged(e));

                //---- backToMainHome ----
                backToMainHome.setText("\u8fd4\u56de\u767b\u5f55\u754c\u9762");
                backToMainHome.addActionListener(e -> backToMainHome(e));

                //---- variableButton ----
                variableButton.setText("\u6ce8\u518c");
                variableButton.addActionListener(e -> variable(e));

                //---- tips ----
                tips.setHorizontalAlignment(SwingConstants.CENTER);
                tips.setForeground(Color.red);

                //---- findButton ----
                findButton.setText("\u67e5\u627e");
                findButton.addActionListener(e -> find(e));

                GroupLayout contentPanelLayout = new GroupLayout(contentPanel);
                contentPanel.setLayout(contentPanelLayout);
                contentPanelLayout.setHorizontalGroup(
                    contentPanelLayout.createParallelGroup()
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                            .addGap(96, 96, 96)
                            .addComponent(backToMainHome)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(findButton)
                            .addGap(69, 69, 69)
                            .addComponent(variableButton, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE)
                            .addGap(129, 129, 129))
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                            .addGap(0, 20, Short.MAX_VALUE)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addComponent(schoollabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(passwordlabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(schoolLevellabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(homelabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(dreamschoolTypelabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(acoountlabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(dreamschoolNamelabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
                                .addComponent(dreamschoolLoclabel, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addGap(85, 85, 85)
                                    .addComponent(label9, GroupLayout.PREFERRED_SIZE, 251, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label1, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(studentNameTextField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label3, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(schoolField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label4, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(schoolLevelField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label5, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(homeField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label6, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(dreamSchoolLevelField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label7, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(dreamSchoolPlaceField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label8, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(dreamSchoolNameField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addComponent(label2, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(studentpasswordField, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(showPasswordRadioButton)))
                            .addGap(69, 69, 69))
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                            .addContainerGap(20, Short.MAX_VALUE)
                            .addComponent(tips, GroupLayout.PREFERRED_SIZE, 618, GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(26, Short.MAX_VALUE))
                );
                contentPanelLayout.setVerticalGroup(
                    contentPanelLayout.createParallelGroup()
                        .addGroup(contentPanelLayout.createSequentialGroup()
                            .addGap(15, 15, 15)
                            .addComponent(label9)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addGroup(contentPanelLayout.createSequentialGroup()
                                    .addGroup(contentPanelLayout.createParallelGroup()
                                        .addGroup(contentPanelLayout.createSequentialGroup()
                                            .addGap(18, 18, 18)
                                            .addGroup(contentPanelLayout.createParallelGroup()
                                                .addComponent(label1, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(studentNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                            .addGap(12, 12, 12)
                                            .addGroup(contentPanelLayout.createParallelGroup()
                                                .addComponent(passwordlabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(label2, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addGroup(contentPanelLayout.createSequentialGroup()
                                                    .addGap(1, 1, 1)
                                                    .addGroup(contentPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(studentpasswordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(showPasswordRadioButton))))
                                            .addGap(12, 12, 12)
                                            .addGroup(contentPanelLayout.createParallelGroup()
                                                .addComponent(label3, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(schoolField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(schoollabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(contentPanelLayout.createParallelGroup()
                                                .addComponent(label4, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(schoolLevelField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(schoolLevellabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
                                            .addGap(12, 12, 12)
                                            .addGroup(contentPanelLayout.createParallelGroup()
                                                .addComponent(label5, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(homeField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(homelabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
                                            .addGap(12, 12, 12)
                                            .addGroup(contentPanelLayout.createParallelGroup()
                                                .addComponent(label6, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(dreamSchoolLevelField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(dreamschoolTypelabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(contentPanelLayout.createSequentialGroup()
                                            .addGap(18, 18, 18)
                                            .addComponent(acoountlabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)))
                                    .addGap(12, 12, 12)
                                    .addGroup(contentPanelLayout.createParallelGroup()
                                        .addComponent(label7, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(dreamSchoolPlaceField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                                .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(dreamschoolLoclabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)))
                            .addGap(8, 8, 8)
                            .addGroup(contentPanelLayout.createParallelGroup()
                                .addComponent(label8, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
                                .addComponent(dreamSchoolNameField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                .addComponent(dreamschoolNamelabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addComponent(tips, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(contentPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(backToMainHome)
                                .addComponent(variableButton)
                                .addComponent(findButton))
                            .addContainerGap(30, Short.MAX_VALUE))
                );
            }
            dialogPane.add(contentPanel, BorderLayout.NORTH);
        }
        contentPane.add(dialogPane, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel dialogPane;
    private JPanel contentPanel;
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JLabel label4;
    private JLabel label5;
    private JLabel label6;
    private JLabel label7;
    private JLabel label8;
    private JLabel label9;
    private JTextField studentNameTextField;
    private JTextField schoolField;
    private JTextField schoolLevelField;
    private JTextField homeField;
    private JTextField dreamSchoolLevelField;
    private JTextField dreamSchoolPlaceField;
    private JTextField dreamSchoolNameField;
    private JPasswordField studentpasswordField;
    private JRadioButton showPasswordRadioButton;
    private JButton backToMainHome;
    private JButton variableButton;
    private JLabel tips;
    private JLabel dreamschoolNamelabel;
    private JLabel passwordlabel;
    private JLabel schoollabel;
    private JLabel schoolLevellabel;
    private JLabel homelabel;
    private JLabel dreamschoolTypelabel;
    private JLabel acoountlabel;
    private JLabel dreamschoolLoclabel;
    private JButton findButton;
    // JFormDesigner - End of variables declaration  //GEN-END:variables

    public static void main(String[] args) {
        ModifyStudentInfoDialog modifyStudentInfoDialog = new ModifyStudentInfoDialog(loginFrame,2);
        modifyStudentInfoDialog.setVisible(true);
    }
}
