/*
 * Created by JFormDesigner on Wed Apr 20 15:06:46 CST 2022
 */

package UI;

import Utils.CommonData;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.GroupLayout;
import javax.swing.border.*;

import static Utils.CommonData.*;

/**
 * @author 1
 */
public class MainFrameForAdmin extends JFrame {
    public MainFrameForAdmin() {
        initComponents();
    }

    private void viewCurrrentAdminInfo(ActionEvent e) {
        adminDAO.ViewSelectedAdmin(admin.getAdminName());
    }

    private void modifyCurrentAdminInfo(ActionEvent e) {
        ModifyAdminInfoDialog modifyAdminInfoDialog = new ModifyAdminInfoDialog(mainFrameForAdmin,1);

        modifyAdminInfoDialog.setVisible(true);
    }

    private void addAminInfoItem(ActionEvent e) {
        ModifyAdminInfoDialog modifyAdminInfoDialog = new ModifyAdminInfoDialog(mainFrameForAdmin,2);

        modifyAdminInfoDialog.setVisible(true);
    }

    private void delAdminItem(ActionEvent e) {
        ModifyAdminInfoDialog modifyAdminInfoDialog = new ModifyAdminInfoDialog(mainFrameForAdmin,3);

        modifyAdminInfoDialog.setVisible(true);
    }

    private void quitSystem(ActionEvent e) {
        System.exit(0);
    }

    private void quitLogin(ActionEvent e) {
        mainFrameForAdmin.dispose();
        if(loginFrame.rememberAccountcheckBox.isSelected()&&loginFrame.rememberPasswordcheckBox.isSelected()){
            loginFrame.loginPrompt.setText("");
            loginFrame.setVisible(true);
        } else if( loginFrame.rememberAccountcheckBox.isSelected()) {
            loginFrame.passwordField.setText("");
            loginFrame.loginPrompt.setText("");
            loginFrame.setVisible(true);
            admin = null;
        }else if( loginFrame.rememberPasswordcheckBox.isSelected()) {
            loginFrame.AccountTextField.setText("");
            loginFrame.loginPrompt.setText("");
            loginFrame.setVisible(true);
            admin = null;
        }

    }

    private void addSchoolInfoMenu(ActionEvent e) {
        ModifySchoolInfoDialog modifySchoolInfoDialog = new ModifySchoolInfoDialog(mainFrameForAdmin,1);
        modifySchoolInfoDialog.setVisible(true);
    }

    private void delSchoolInfoMenu(ActionEvent e) {
        ModifySchoolInfoDialog modifySchoolInfoDialog = new ModifySchoolInfoDialog(mainFrameForAdmin,2);
        modifySchoolInfoDialog.setVisible(true);
    }

    private void modifySchoolInfoMenu(ActionEvent e) {
        ModifySchoolInfoDialog modifySchoolInfoDialog = new ModifySchoolInfoDialog(mainFrameForAdmin,3);
        modifySchoolInfoDialog.setVisible(true);
    }

    private void addSchoolListMenu(ActionEvent e) {
        ModifySchoolListDialog modifySchoolListDialog = new ModifySchoolListDialog(mainFrameForAdmin,1);
        modifySchoolListDialog.setVisible(true);
    }

    private void delSchoolListMenu(ActionEvent e) {
        ModifySchoolListDialog modifySchoolListDialog = new ModifySchoolListDialog(mainFrameForAdmin,2);
        modifySchoolListDialog.setVisible(true);
    }

    private void modifySchoolListMenu(ActionEvent e) {
        ModifySchoolListDialog modifySchoolListDialog = new ModifySchoolListDialog(mainFrameForAdmin,3);
        modifySchoolListDialog.setVisible(true);
    }



    /*这个是增加学校信息*/

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        menuBar1 = new JMenuBar();
        menu1 = new JMenu();
        viewCurrrentAdminInfo = new JMenuItem();
        menuItem2 = new JMenuItem();
        menuItem37 = new JMenuItem();
        modifyCurrentAdminInfo = new JMenuItem();
        addAminInfoItem = new JMenuItem();
        menu7 = new JMenu();
        delAdminItem = new JMenuItem();
        quitSystem = new JMenuItem();
        quitLogin = new JMenuItem();
        menu2 = new JMenu();
        menu8 = new JMenu();
        addSchoolInfoMenu = new JMenuItem();
        delSchoolInfoMenu = new JMenuItem();
        modifySchoolInfoMenu = new JMenuItem();
        menu13 = new JMenu();
        addSchoolListMenu = new JMenuItem();
        delSchoolListMenu = new JMenuItem();
        modifySchoolListMenu = new JMenuItem();
        menu3 = new JMenu();
        menu9 = new JMenu();
        menuItem10 = new JMenuItem();
        menuItem12 = new JMenuItem();
        menuItem13 = new JMenuItem();
        menuItem14 = new JMenuItem();
        menuItem15 = new JMenuItem();
        menuItem16 = new JMenuItem();
        menuItem17 = new JMenuItem();
        menu10 = new JMenu();
        menuItem38 = new JMenuItem();
        menuItem39 = new JMenuItem();
        menuItem40 = new JMenuItem();
        menuItem41 = new JMenuItem();
        menu6 = new JMenu();
        menuItem31 = new JMenuItem();
        menuItem32 = new JMenuItem();
        menuItem33 = new JMenuItem();
        dialogPane = new JPanel();
        contentPanel = new JPanel();
        adminMainLabel = new JLabel();

        //======== this ========
        setTitle("\u7ba1\u7406\u5458\u7cfb\u7edf");
        var contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== menuBar1 ========
        {

            //======== menu1 ========
            {
                menu1.setText("\u7ba1\u7406\u5458\u4fe1\u606f");

                //---- viewCurrrentAdminInfo ----
                viewCurrrentAdminInfo.setText("\u67e5\u770b\u5f53\u524d\u7ba1\u7406\u5458\u4fe1\u606f");
                viewCurrrentAdminInfo.addActionListener(e -> viewCurrrentAdminInfo(e));
                menu1.add(viewCurrrentAdminInfo);

                //---- menuItem2 ----
                menuItem2.setText("\u67e5\u770b\u6240\u6709\u7ba1\u7406\u5458\u4fe1\u606f");
                menu1.add(menuItem2);

                //---- menuItem37 ----
                menuItem37.setText("\u67e5\u770b\u6307\u5b9a\u7ba1\u7406\u5458\u4fe1\u606f");
                menu1.add(menuItem37);

                //---- modifyCurrentAdminInfo ----
                modifyCurrentAdminInfo.setText("\u4fee\u6539\u5f53\u524d\u7ba1\u7406\u5458\u4fe1\u606f");
                modifyCurrentAdminInfo.addActionListener(e -> {
			modifyCurrentAdminInfo(e);
			modifyCurrentAdminInfo(e);
		});
                menu1.add(modifyCurrentAdminInfo);

                //---- addAminInfoItem ----
                addAminInfoItem.setText("\u589e\u52a0\u7ba1\u7406\u5458\u4fe1\u606f");
                addAminInfoItem.addActionListener(e -> addAminInfoItem(e));
                menu1.add(addAminInfoItem);

                //======== menu7 ========
                {
                    menu7.setText("\u9ad8\u5371\u9009\u9879");

                    //---- delAdminItem ----
                    delAdminItem.setText("\u5220\u9664\u7279\u5b9a\u7ba1\u7406\u5458\u4fe1\u606f");
                    delAdminItem.addActionListener(e -> delAdminItem(e));
                    menu7.add(delAdminItem);

                    //---- quitSystem ----
                    quitSystem.setText("\u505c\u6b62\u7cfb\u7edf\u670d\u52a1");
                    quitSystem.addActionListener(e -> quitSystem(e));
                    menu7.add(quitSystem);
                }
                menu1.add(menu7);

                //---- quitLogin ----
                quitLogin.setText("\u9000\u51fa\u767b\u5f55");
                quitLogin.addActionListener(e -> {
			quitLogin(e);
			quitLogin(e);
		});
                menu1.add(quitLogin);
            }
            menuBar1.add(menu1);

            //======== menu2 ========
            {
                menu2.setText("\u9662\u6821\u4fee\u6539");

                //======== menu8 ========
                {
                    menu8.setText("\u589e\u52a0/\u5220\u9664/\u4fee\u6539\u9662\u6821\u4fe1\u606f");

                    //---- addSchoolInfoMenu ----
                    addSchoolInfoMenu.setText("\u589e\u52a0\u9662\u6821");
                    addSchoolInfoMenu.addActionListener(e -> addSchoolInfoMenu(e));
                    menu8.add(addSchoolInfoMenu);

                    //---- delSchoolInfoMenu ----
                    delSchoolInfoMenu.setText("\u5220\u9664\u9662\u6821");
                    delSchoolInfoMenu.addActionListener(e -> delSchoolInfoMenu(e));
                    menu8.add(delSchoolInfoMenu);

                    //---- modifySchoolInfoMenu ----
                    modifySchoolInfoMenu.setText("\u4fee\u6539\u9662\u6821");
                    modifySchoolInfoMenu.addActionListener(e -> modifySchoolInfoMenu(e));
                    menu8.add(modifySchoolInfoMenu);
                }
                menu2.add(menu8);

                //======== menu13 ========
                {
                    menu13.setText("\u589e\u52a0/\u5220\u9664/\u4fee\u6539\u9662\u6821\u5217\u8868");

                    //---- addSchoolListMenu ----
                    addSchoolListMenu.setText("\u589e\u52a0\u9662\u6821");
                    addSchoolListMenu.addActionListener(e -> addSchoolListMenu(e));
                    menu13.add(addSchoolListMenu);

                    //---- delSchoolListMenu ----
                    delSchoolListMenu.setText("\u5220\u9664\u9662\u6821");
                    delSchoolListMenu.addActionListener(e -> delSchoolListMenu(e));
                    menu13.add(delSchoolListMenu);

                    //---- modifySchoolListMenu ----
                    modifySchoolListMenu.setText("\u4fee\u6539\u9662\u6821");
                    modifySchoolListMenu.addActionListener(e -> modifySchoolListMenu(e));
                    menu13.add(modifySchoolListMenu);
                }
                menu2.add(menu13);
            }
            menuBar1.add(menu2);

            //======== menu3 ========
            {
                menu3.setText("\u67e5\u8be2\u9662\u6821");

                //======== menu9 ========
                {
                    menu9.setText("\u6309\u5730\u533a\u67e5\u8be2");

                    //---- menuItem10 ----
                    menuItem10.setText("\u5b89\u5fbd");
                    menu9.add(menuItem10);

                    //---- menuItem12 ----
                    menuItem12.setText("\u6c5f\u82cf");
                    menu9.add(menuItem12);

                    //---- menuItem13 ----
                    menuItem13.setText("\u4e0a\u6d77");
                    menu9.add(menuItem13);

                    //---- menuItem14 ----
                    menuItem14.setText("\u5e7f\u4e1c");
                    menu9.add(menuItem14);

                    //---- menuItem15 ----
                    menuItem15.setText("\u8d35\u5dde");
                    menu9.add(menuItem15);

                    //---- menuItem16 ----
                    menuItem16.setText("\u56db\u5ddd");
                    menu9.add(menuItem16);

                    //---- menuItem17 ----
                    menuItem17.setText("\u6c5f\u897f");
                    menu9.add(menuItem17);
                }
                menu3.add(menu9);

                //======== menu10 ========
                {
                    menu10.setText("\u6309\u7c7b\u522b\u67e5\u8be2");

                    //---- menuItem38 ----
                    menuItem38.setText("\u67e5\u8be2985\u9662\u6821");
                    menu10.add(menuItem38);

                    //---- menuItem39 ----
                    menuItem39.setText("\u67e5\u8be2211\u9662\u6821");
                    menu10.add(menuItem39);

                    //---- menuItem40 ----
                    menuItem40.setText("\u67e5\u8be2\u666e\u672c\u9662\u6821");
                    menu10.add(menuItem40);
                }
                menu3.add(menu10);

                //---- menuItem41 ----
                menuItem41.setText("\u67e5\u8be2\u6307\u5b9a\u9662\u6821\u4fe1\u606f");
                menu3.add(menuItem41);
            }
            menuBar1.add(menu3);

            //======== menu6 ========
            {
                menu6.setText("\u64cd\u4f5c\u7528\u6237\u4fe1\u606f");

                //---- menuItem31 ----
                menuItem31.setText("\u67e5\u8be2\u6240\u6709\u7528\u6237\u4fe1\u606f");
                menu6.add(menuItem31);

                //---- menuItem32 ----
                menuItem32.setText("\u6839\u636e\u7528\u6237\u540d\u67e5\u8be2");
                menu6.add(menuItem32);

                //---- menuItem33 ----
                menuItem33.setText("\u5220\u9664\u7528\u6237\u4fe1\u606f");
                menu6.add(menuItem33);
            }
            menuBar1.add(menu6);
        }
        setJMenuBar(menuBar1);

        //======== dialogPane ========
        {
            dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
            dialogPane.setLayout(new BorderLayout());

            //======== contentPanel ========
            {

                //---- adminMainLabel ----
                adminMainLabel.setText("\u6b22\u8fce");
                adminMainLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 28));
                adminMainLabel.setHorizontalAlignment(SwingConstants.CENTER);

                GroupLayout contentPanelLayout = new GroupLayout(contentPanel);
                contentPanel.setLayout(contentPanelLayout);
                contentPanelLayout.setHorizontalGroup(
                    contentPanelLayout.createParallelGroup()
                        .addGroup(contentPanelLayout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(adminMainLabel, GroupLayout.DEFAULT_SIZE, 692, Short.MAX_VALUE)
                            .addContainerGap())
                );
                contentPanelLayout.setVerticalGroup(
                    contentPanelLayout.createParallelGroup()
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPanelLayout.createSequentialGroup()
                            .addContainerGap(89, Short.MAX_VALUE)
                            .addComponent(adminMainLabel, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)
                            .addGap(122, 122, 122))
                );
            }
            dialogPane.add(contentPanel, BorderLayout.CENTER);
        }
        contentPane.add(dialogPane, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JMenuBar menuBar1;
    private JMenu menu1;
    private JMenuItem viewCurrrentAdminInfo;
    private JMenuItem menuItem2;
    private JMenuItem menuItem37;
    private JMenuItem modifyCurrentAdminInfo;
    private JMenuItem addAminInfoItem;
    private JMenu menu7;
    private JMenuItem delAdminItem;
    private JMenuItem quitSystem;
    private JMenuItem quitLogin;
    private JMenu menu2;
    private JMenu menu8;
    private JMenuItem addSchoolInfoMenu;
    private JMenuItem delSchoolInfoMenu;
    private JMenuItem modifySchoolInfoMenu;
    private JMenu menu13;
    private JMenuItem addSchoolListMenu;
    private JMenuItem delSchoolListMenu;
    private JMenuItem modifySchoolListMenu;
    private JMenu menu3;
    private JMenu menu9;
    private JMenuItem menuItem10;
    private JMenuItem menuItem12;
    private JMenuItem menuItem13;
    private JMenuItem menuItem14;
    private JMenuItem menuItem15;
    private JMenuItem menuItem16;
    private JMenuItem menuItem17;
    private JMenu menu10;
    private JMenuItem menuItem38;
    private JMenuItem menuItem39;
    private JMenuItem menuItem40;
    private JMenuItem menuItem41;
    private JMenu menu6;
    private JMenuItem menuItem31;
    private JMenuItem menuItem32;
    private JMenuItem menuItem33;
    private JPanel dialogPane;
    private JPanel contentPanel;
    private JLabel adminMainLabel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    public static void main(String[] args) {
        mainFrameForAdmin.setVisible(true);
    }
}
