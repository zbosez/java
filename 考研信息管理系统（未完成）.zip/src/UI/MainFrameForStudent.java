/*
 * Created by JFormDesigner on Wed Apr 20 10:34:29 CST 2022
 */

package UI;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.GroupLayout;

import static Utils.CommonData.*;
import static Utils.CommonData.loginFrame;

/**
 * @author 1
 */
public class MainFrameForStudent extends JFrame {
    public MainFrameForStudent() {
        initComponents();
    }

    private void button1MouseClicked(MouseEvent e) {
        // TODO add your code here

    }

    private void delStudent(ActionEvent e) {
        ModifyStudentInfoDialog modifyStudentInfoDialog = new ModifyStudentInfoDialog(mainFrameForStudent,2);
        modifyStudentInfoDialog.setVisible(true);
    }

    private void modifyStudent(ActionEvent e) {
        ModifyStudentInfoDialog modifyStudentInfoDialog = new ModifyStudentInfoDialog(mainFrameForStudent,3);
        modifyStudentInfoDialog.setVisible(true);
    }

    private void quitLogin(ActionEvent e) {
        mainFrameForStudent.dispose();
        if(loginFrame.rememberAccountcheckBox.isSelected()&&loginFrame.rememberPasswordcheckBox.isSelected()){
            loginFrame.loginPrompt.setText("");
            loginFrame.setVisible(true);
        } else if( loginFrame.rememberAccountcheckBox.isSelected()) {
            loginFrame.passwordField.setText("");
            loginFrame.loginPrompt.setText("");
            loginFrame.setVisible(true);
            student = null;
        }else if( loginFrame.rememberPasswordcheckBox.isSelected()) {
            loginFrame.AccountTextField.setText("");
            loginFrame.loginPrompt.setText("");
            loginFrame.setVisible(true);
            student=null;
        }
    }

    private void quitSystem(ActionEvent e) {
        System.exit(0);
    }

    private void checkSystemUpdateTime(ActionEvent e) {
        JOptionPane.showMessageDialog(mainFrameForStudent,"ϵͳ��Ϣ����ʱ����:2021�꿼����Ϣ!��");
    }

    private void aboutUs(ActionEvent e) {
        JOptionPane.showMessageDialog(mainFrameForStudent,"������zbossz��д�����ݿ���Ϣ�����zbossz����Ѱ����������ͬ��ɣ�");
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        menuBar1 = new JMenuBar();
        menu3 = new JMenu();
        menuItem1 = new JMenuItem();
        modifyStudentmenuItem = new JMenuItem();
        delStudentmenuItem = new JMenuItem();
        quitLoginmenuItem = new JMenuItem();
        menu7 = new JMenu();
        menu9 = new JMenu();
        menuItem30 = new JMenuItem();
        menuItem31 = new JMenuItem();
        menuItem32 = new JMenuItem();
        menuItem33 = new JMenuItem();
        menuItem34 = new JMenuItem();
        menuItem35 = new JMenuItem();
        menuItem36 = new JMenuItem();
        menu10 = new JMenu();
        menuItem38 = new JMenuItem();
        menuItem39 = new JMenuItem();
        menuItem40 = new JMenuItem();
        menuItem4 = new JMenuItem();
        menu5 = new JMenu();
        menuItem2 = new JMenuItem();
        menuItem5 = new JMenuItem();
        menuItem6 = new JMenuItem();
        menu6 = new JMenu();
        checkSystemUpdateTimemenuItem = new JMenuItem();
        aboutUsmenuItem = new JMenuItem();
        quitSystemmenuItem = new JMenuItem();
        studentMainLabel = new JLabel();

        //======== this ========
        setTitle("\u5b66\u751f\u7cfb\u7edf");
        var contentPane = getContentPane();

        //======== menuBar1 ========
        {

            //======== menu3 ========
            {
                menu3.setText("\u4e2a\u4eba\u4fe1\u606f");

                //---- menuItem1 ----
                menuItem1.setText("\u67e5\u770b\u4fe1\u606f");
                menu3.add(menuItem1);

                //---- modifyStudentmenuItem ----
                modifyStudentmenuItem.setText("\u4fee\u6539\u4fe1\u606f");
                modifyStudentmenuItem.addActionListener(e -> modifyStudent(e));
                menu3.add(modifyStudentmenuItem);

                //---- delStudentmenuItem ----
                delStudentmenuItem.setText("\u6ce8\u9500\u7528\u6237");
                delStudentmenuItem.addActionListener(e -> delStudent(e));
                menu3.add(delStudentmenuItem);

                //---- quitLoginmenuItem ----
                quitLoginmenuItem.setText("\u9000\u51fa\u767b\u5f55");
                quitLoginmenuItem.addActionListener(e -> quitLogin(e));
                menu3.add(quitLoginmenuItem);
            }
            menuBar1.add(menu3);

            //======== menu7 ========
            {
                menu7.setText("\u67e5\u8be2\u9662\u6821");

                //======== menu9 ========
                {
                    menu9.setText("\u6309\u5730\u533a\u67e5\u8be2\u9662\u6821\u540d\u5355");

                    //---- menuItem30 ----
                    menuItem30.setText("\u5b89\u5fbd");
                    menu9.add(menuItem30);

                    //---- menuItem31 ----
                    menuItem31.setText("\u6c5f\u82cf");
                    menu9.add(menuItem31);

                    //---- menuItem32 ----
                    menuItem32.setText("\u4e0a\u6d77");
                    menu9.add(menuItem32);

                    //---- menuItem33 ----
                    menuItem33.setText("\u5e7f\u4e1c");
                    menu9.add(menuItem33);

                    //---- menuItem34 ----
                    menuItem34.setText("\u8d35\u5dde");
                    menu9.add(menuItem34);

                    //---- menuItem35 ----
                    menuItem35.setText("\u56db\u5ddd");
                    menu9.add(menuItem35);

                    //---- menuItem36 ----
                    menuItem36.setText("\u6c5f\u897f");
                    menu9.add(menuItem36);
                }
                menu7.add(menu9);

                //======== menu10 ========
                {
                    menu10.setText("\u6309\u7c7b\u522b\u67e5\u8be2\u9662\u6821\u540d\u5355");

                    //---- menuItem38 ----
                    menuItem38.setText("\u67e5\u8be2985\u9662\u6821");
                    menu10.add(menuItem38);

                    //---- menuItem39 ----
                    menuItem39.setText("\u67e5\u8be2211\u9662\u6821");
                    menu10.add(menuItem39);

                    //---- menuItem40 ----
                    menuItem40.setText("\u67e5\u8be2\u666e\u672c\u9662\u6821");
                    menu10.add(menuItem40);
                }
                menu7.add(menu10);

                //---- menuItem4 ----
                menuItem4.setText("\u67e5\u8be2\u6307\u5b9a\u9662\u6821\u4fe1\u606f");
                menu7.add(menuItem4);
            }
            menuBar1.add(menu7);

            //======== menu5 ========
            {
                menu5.setText("\u63a8\u8350\u9662\u6821");

                //---- menuItem2 ----
                menuItem2.setText("\u6309\u7167\u5fd7\u613f\u5b66\u6821\u7c7b\u578b\u63a8\u8350");
                menu5.add(menuItem2);

                //---- menuItem5 ----
                menuItem5.setText("\u6309\u7167\u5fd7\u613f\u5b66\u6821\u5730\u533a\u63a8\u8350");
                menu5.add(menuItem5);

                //---- menuItem6 ----
                menuItem6.setText("\u67e5\u770b\u4e2a\u4eba\u5fd7\u613f\u5b66\u6821\u4fe1\u606f");
                menu5.add(menuItem6);
            }
            menuBar1.add(menu5);

            //======== menu6 ========
            {
                menu6.setText("\u8bbe\u7f6e");

                //---- checkSystemUpdateTimemenuItem ----
                checkSystemUpdateTimemenuItem.setText("\u67e5\u770b\u7cfb\u7edf\u66f4\u65b0\u65f6\u95f4");
                checkSystemUpdateTimemenuItem.addActionListener(e -> checkSystemUpdateTime(e));
                menu6.add(checkSystemUpdateTimemenuItem);

                //---- aboutUsmenuItem ----
                aboutUsmenuItem.setText("\u5173\u4e8e\u6211\u4eec");
                aboutUsmenuItem.addActionListener(e -> aboutUs(e));
                menu6.add(aboutUsmenuItem);

                //---- quitSystemmenuItem ----
                quitSystemmenuItem.setText("\u9000\u51fa");
                quitSystemmenuItem.addActionListener(e -> quitSystem(e));
                menu6.add(quitSystemmenuItem);
            }
            menuBar1.add(menu6);
        }
        setJMenuBar(menuBar1);

        //---- studentMainLabel ----
        studentMainLabel.setText("\u6b22\u8fce");
        studentMainLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 28));
        studentMainLabel.setHorizontalAlignment(SwingConstants.CENTER);

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createParallelGroup()
                    .addGroup(contentPaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(studentMainLabel, GroupLayout.PREFERRED_SIZE, 692, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(0, 813, Short.MAX_VALUE)
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createParallelGroup()
                    .addGroup(contentPaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(studentMainLabel, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(0, 456, Short.MAX_VALUE)
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JMenuBar menuBar1;
    private JMenu menu3;
    private JMenuItem menuItem1;
    private JMenuItem modifyStudentmenuItem;
    private JMenuItem delStudentmenuItem;
    private JMenuItem quitLoginmenuItem;
    private JMenu menu7;
    private JMenu menu9;
    private JMenuItem menuItem30;
    private JMenuItem menuItem31;
    private JMenuItem menuItem32;
    private JMenuItem menuItem33;
    private JMenuItem menuItem34;
    private JMenuItem menuItem35;
    private JMenuItem menuItem36;
    private JMenu menu10;
    private JMenuItem menuItem38;
    private JMenuItem menuItem39;
    private JMenuItem menuItem40;
    private JMenuItem menuItem4;
    private JMenu menu5;
    private JMenuItem menuItem2;
    private JMenuItem menuItem5;
    private JMenuItem menuItem6;
    private JMenu menu6;
    private JMenuItem checkSystemUpdateTimemenuItem;
    private JMenuItem aboutUsmenuItem;
    private JMenuItem quitSystemmenuItem;
    private JLabel studentMainLabel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    public static void main(String[] args) {
        mainFrameForStudent.setVisible(true);
    }
}
